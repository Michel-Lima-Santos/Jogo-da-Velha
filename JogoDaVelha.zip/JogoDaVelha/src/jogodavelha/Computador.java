package jogodavelha; // Pacote que armazenará as Classes

public interface Computador //Classe Mãe "Computador" que permitirá a realização do Polimorfismo das três Classes filhas "Nivel1", "Nivel2" e "Nivel3"
{
	public void joga(Tabuleiro tab);
}
